var adicao = require("./operacoes.js");
var _ = require("lodash");

console.log(adicao.adicao(8, 4));
console.log(adicao.subtracao(15, 7));
console.log(adicao.multiplicacao(6, 3));
console.log(adicao.divisao(20, 5));
console.log(adicao.divisao(10, 0));

console.log(_.random(1, 30));